package com.actitime.qa.pages;

import com.actitime.qa.base.TestBase;

public class ReportsPage extends TestBase  {

	
	// Web Element Xpath 
	
	
	// Call init
	
	// Mathod
	
}
