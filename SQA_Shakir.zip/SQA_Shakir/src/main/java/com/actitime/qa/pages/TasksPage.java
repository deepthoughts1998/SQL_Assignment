package com.actitime.qa.pages;

import com.actitime.qa.base.TestBase;

public class TasksPage extends TestBase {

	
	
}
