package com.actitime.qa.testdata;

import com.actitime.qa.base.TestBase;

public class TestData extends TestBase {
    public TestData() {
        super();
    }
    public static final String FIRST_NAME = "Claire";
    public static final String MIDDLE_NAME = "EL";
    public static final String LAST_NAME= "Cottrill";
    public static final String EMAIL = "clairecotroll@gmail.com";
    public static final String DEPARTMENT = "Quality Control";
}
