Please find the test plan and the automation scripts for the assignment here
